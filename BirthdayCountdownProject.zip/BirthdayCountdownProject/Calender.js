function calculateDays() {
    const userInput = prompt("Enter your birthday (YYYY-MM-DD):");
    
    // Parse user input to create a Date object
    const birthday = new Date(userInput);
    
    // Current date
    const currentDate = new Date();
    
    // Set the current year for the birthday
    birthday.setFullYear(currentDate.getFullYear());
    
    // If the birthday has already occurred this year, set it to next year
    if (birthday.getTime() < currentDate.getTime()) {
        birthday.setFullYear(currentDate.getFullYear() + 1);
    }
    
    // Calculate the difference in milliseconds
    const difference = birthday.getTime() - currentDate.getTime();
    
    // Convert the difference to days
    const days = Math.ceil(difference / (1000 * 3600 * 24));
    
    // Output the result
    if (days === 0) {
        alert("Happy Birthday!");
    } else if (days > 0) {
        alert("There are " + days + " days left until your next birthday.");
    } else {
        alert("There are " + Math.abs(days) + " days since your last birthday.");
    }
}

// Call the function to start the calculation
calculateDays();
  